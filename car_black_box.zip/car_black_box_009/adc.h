/* 
 * File:   adc.h
  * Name : R KEERTHANA
 */

#ifndef ADC_H
#define	ADC_H

/*functions prototypes*/
void init_adc(void);
unsigned short read_adc(void);

#endif	/* ADC_H */


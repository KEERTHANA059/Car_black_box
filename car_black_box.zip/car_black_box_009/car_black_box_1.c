/*
 * File:  car_black_box_1.c
 * Name : R KEERTHANA
 */

#include <xc.h>
#include "main.h"

/*declare global variables*/
unsigned char clock_reg[3],new_time[3];
char time[9],log[16],pos = -1,*menu[]={"View log","Clear log","Download log","Reset time","Change passwd"};
int access = 0,second,minute,return_time,timer_flag = 1;

/*function to get time from real time clock*/
void get_time(void)
{
    /*read values from ds1307 register*/
    clock_reg[0] = read_ds1307(HOUR_ADDR); // HH -> BCD 
    clock_reg[1] = read_ds1307(MIN_ADDR); // MM -> BCD 
    clock_reg[2] = read_ds1307(SEC_ADDR); // SS -> BCD 
      // HH -> 
    
    /*convert BCD to ASCII*/
    time[0] = ((clock_reg[0] >> 4) & 0x03) + '0';
    time[1] = (clock_reg[0] & 0x0F) + '0';
    
    time[2] = ':';
    // MM 
    time[3] = ((clock_reg[1] >> 4) & 0x07) + '0';
    time[4] = (clock_reg[1] & 0x0F) + '0';
    
    time[5] = ':';
    // SS
    time[6] = ((clock_reg[2] >> 4) & 0x07) + '0';
    time[7] = (clock_reg[2] & 0x0F) + '0';
    time[8] = '\0';
}

/*function to display time in clcd*/
void display_time(void)
{
    
    /*using flag to display time before reset the timer*/
    if(timer_flag == 1)
    {
        get_time();
        clcd_print(time ,LINE2(2));
    }
    
    /*using flag to display time while resetting the timer*/
    else
    {
        clcd_putch( new_time[0] / 10 + 48, LINE2(0));
		clcd_putch( new_time[0] % 10 + 48 , LINE2(1));
		clcd_putch( ':', LINE2(2));
		clcd_putch( new_time[1] / 10 + 48, LINE2(3));
		clcd_putch( new_time[1] % 10 + 48, LINE2(4));
		clcd_putch( ':', LINE2(5));
		clcd_putch( new_time[2] / 10 + 48 , LINE2(6));
		clcd_putch( new_time[2] % 10 + 48, LINE2(7));
    }
}

/* function to set time */
void set_time(unsigned char reset_flag,unsigned char key)
{
    /* declare local variables*/
    static char field = 0xC7; static int index = 2;static unsigned delay=0;
    
    /*if flag equal to reset time write initial values to the variables*/
    if(reset_flag == RESET_TIME)
    {
        index = 2;
        delay=0;
        field = 0xC7;
    }
    
    /* flag to display timer values before editing */
    if(timer_flag == 1)
    {
        timer_flag = 0;
        clcd_print("TIME (HH:MM:SS)",0x80);
        display_time();
        new_time[2] = (time[7] - '0') + ((time[6] - '0') * 10);
        new_time[1] = (time[4] - '0') + ((time[3] - '0') * 10);
        new_time[0] = (time[1] - '0') + ((time[0] - '0') * 10);
    }
    
    /*if switch 4 is pressed increment timer values*/
    if(key == SW4 && key != L_SW4)
    {  
        if (index == 2 &&  ++new_time[2] > 59 )
            new_time[2] = 0;
        else if (index == 1 &&  ++new_time[1] > 59 )
            new_time[1] = 0;
        else if( index == 0 &&  ++new_time[0]  > 23 )
            new_time[0] = 0;
    }
    
    /* if switch 5 is pressed change the field */
    if(key == SW5)
    {
        field -= 3;
        if(--index <= -1)
            index = 0;
        if(field < 0xC0)
        {
            field = 0xC7;
        }   
    }
    
    /* condition for blinking */
    if(delay++ == 60)
    {
        clcd_print("  ",field-1);
    }
    if(delay == 130)
    {
        display_time();
        delay = 0;
    }
}

/* function to display in dash board*/
void display_dash_board(unsigned char event[],unsigned char speed)
{
    clcd_print("TIME     E  SP",LINE1(2));
    
    display_time();
    
    //to display events
    clcd_print(event,LINE2(11));
    
    //to display speed
    clcd_putch(speed/10 + '0',LINE2(14));
    clcd_putch(speed%10 + '0',LINE2(15));
    
}

/* function to store log events */
void log_car_event (void)
{
    char addr;
    addr = 6;
    if(pos++ == 9)
        pos = 0;
    addr = pos * 16 + addr;
    
    /*to store log events in eeprom*/
    eeprom_at24c04_str_write(addr, log);// hhmmssggsp
    if (access < 9 )
        access++;
}

/* read values to log event */
void log_event(unsigned char event[],unsigned char speed)
{
    static int once = 1;
    if(once)
    {
        once = 1;
        get_time();
    }
    
    /*store all information into a single array*/
    strncpy(log,time,8);
    log[8]=' ';
    strncpy(&log[9],event,2);
    log[11]=' ';
    log[12]=speed/10 + '0';
    log[13]=speed%10 + '0';
    log[14] = '\0';
    log_car_event();
}

/*function to login to the */
unsigned char login(unsigned char reset_flag,unsigned char key)
{
    /*declare local variables*/
    static char passwords[4],i;
    static unsigned char attempt_left;
    
    /*if reset flag equal to reset password initialize the variables */
    if(reset_flag == RESET_PASSWORD )
    {
        i=0;
        attempt_left = 3;
        passwords[0]='\0';
        passwords[1]='\0';
        passwords[2]='\0';
        passwords[3]='\0';
        key = ALL_RELEASED;
        second=0;minute=0;
        return_time = 3;
    }
    
    /*when return time is 0 return to the dash board*/
    if( return_time == 0)
    {
        return RETURN_BACK;
    }
    
    /* if switch 4 pressed take entered values as 1 */
    if(key == SW4 && i < 4)
    {
        passwords[i]='1';
        clcd_putch('*',LINE2(5+i));   //display '*' when input given
        i++;
        return_time = 3;
    }
    
    /* if switch 5 pressed take entered values as 0*/
    else if(key == SW5 && i < 4)
    {
        passwords[i]='0';
        clcd_putch('*',LINE2(5+i));     //display '*' when input given
        i++;
        return_time = 3;
    }
    
    /*if 4 characters given then check the user password with default password*/
    if(i == 4)
    {
        char save_password[4];
        
        //read password stored in eeprom
        for(int j=0;j<4;j++)
        {
            save_password[j]=eeprom_at24c04_read(j);
        }
        
        //compare system password with users
        if(strncmp(save_password,passwords,4) == 0)
        {
            clear_screen();
            clcd_print("Login success",LINE1(2)); //if password correct display login success
            __delay_ms(2000);
            return LOGIN_SUCCESS;
            //display menu
        }
        else
        {
            attempt_left--;
            
            //if user given incorrect password for 3 time ,block user for 15 minutes
            if(attempt_left == 0)
            {
                clear_screen();
                cursor_off();
                clcd_print("You are blocked",LINE1(0));
                clcd_print("seconds",LINE2(9));                
                second = 60;minute=14;
                while(second || minute)
                {
                    clcd_putch(second/10+'0',LINE2(3));
                    clcd_putch(second%10+'0',LINE2(4));
                    clcd_putch(':',LINE2(2));
                    clcd_putch(minute/10+'0',LINE2(0));
                    clcd_putch(minute%10+'0',LINE2(1));
                    
                }
                return_time = 3;
                attempt_left = 3;
            }
            else
            {
                /*//if password wrong display wrong password*/
                clear_screen();
                cursor_off();
                clcd_print(" Wrong password ",LINE1(0));
                clcd_putch(attempt_left+'0',LINE2(0));
                clcd_print(" attempt(s)left",LINE2(1));
                __delay_ms(3000);
            }
            
            /*after incorrect password / blocking again display enter password*/
            clear_screen();
            clcd_print("Enter password",LINE1(1));
            clcd_write(LINE2(4),INST_MODE);
            cursor_on();
            i=0;
            return_time = 3;
        }
    }
}

/*function to display main menu*/
unsigned char login_menu(unsigned char reset_flag,unsigned char key)
{
    static unsigned char menu_pos;
    
    /*if reset flag equal to reset password change menu position to 0*/
    if(reset_flag == RESET_PASSWORD)
    {
        clear_screen();
        menu_pos = 0;
    }
    
    /*if key 5 press increment menu position */
    if(key == SW5 && menu_pos < 4)
    {
        clear_screen();
        menu_pos++;
    }
    
    /*if key 4 press increment menu position*/
    if(key == SW4 && menu_pos > 0)
    {
        clear_screen();
        menu_pos--;
    }
    
    /* change start to display selected menu*/
    if(menu_pos < 4)
    {
        clcd_putch('*',LINE1(0));
        clcd_print(menu[menu_pos],LINE1(2));
        clcd_print(menu[menu_pos+1],LINE2(2));
    }
    
    /* when reached to the final menu position change positions in same screen*/
    else if(menu_pos == 4)
    {
        clcd_putch('*',LINE2(0));
        clcd_print(menu[menu_pos-1],LINE1(2));
        clcd_print(menu[menu_pos],LINE2(2));
    }
    return menu_pos;
}

/* function to view the logging details*/
unsigned char view_log (unsigned char reset_flag, unsigned char key)
{
    //declare local variables
    static char addr = 6;unsigned char event[15];static int log_count = 0;
    if (access != -1)
    {
        clcd_print("# TIME     E  SP", LINE1(0));
        
        /*if reset flag equal to reset view log pos then reset variables */
        if (reset_flag == RESET_VIEW_LOG_POS)
        {
            clear_screen();
            addr = 6;
            log_count = 0;
        }
        
        /*if switch 4 is pressed decrease view positions*/
        if (key == SW4 && log_count > 0) // 0 - 9
        {
            addr = addr - 16;
            --log_count;
        }
        
        /*read stored login information from eeprom*/
        for(int i = 0; i < 15; i++)
        {
            event[i] = eeprom_at24c04_read(addr + i);
        }
        if(log_count>=0 && log_count < access){
        clcd_putch(log_count + '0', LINE2(0));
        clcd_print(event,LINE2(2));
        }
        
        /*if switch 5 is pressed increase view positions*/
        if (key == SW5 && log_count < access)
        {
            addr = addr + 16;
            ++log_count;
        }
    }
    
    /*if access equal to -1 display no logs available*/
    else if (access == -1)
    {
        clcd_print("   No log are   ", LINE1(0));
        clcd_print("   Available    ", LINE2(0));
        __delay_ms(300);
        return TASK_FAIL;
    }
}

/*function to clear log informations*/
unsigned char clear_log(unsigned char reset_flag)
{
    char addr = 6;
    
    /*if access equal to -1 display no logs available*/
    if(access == -1)
    {
        clcd_print("   No log are   ", LINE1(0));
        clcd_print("   Available    ", LINE2(0));
        __delay_ms(3000);
    }
    
    /* if reset flag equal to rest memory reset all variable values*/
    if(reset_flag == RESET_MEMORY)
    {
        access = -1;
        pos = -1;
        clcd_print("logs cleared  ",LINE1(2));
        clcd_print("successfully  ",LINE2(2));
        
        /*clear values in addresses*/
        for(int i=0;i<access;i++)
        {
            eeprom_at24c04_byte_write(addr+i,'\0');
        }
        __delay_ms(2000);
        clear_screen();
    }
}

/* function to download login information */
unsigned char download_flag(unsigned char reset_flag)
{
    /*declare local variables*/
    static int index=0,once = 0;
    char event[14],addr=6;
    
    /* if reset flag equal to reset download reset all variables*/
    if(reset_flag == RESET_DOWNLOAD)
    {
        index=once = 0;
    }
    
    /*if access equal to -1 display no logs available*/
    if ( access == -1 )
	{
		puts("     No logs available\n\r");
        clear_screen();
        clcd_print("No log available",LINE1(1));
        __delay_ms(300);
        clear_screen();
        return TASK_FAIL;
	}
    
    /* if access value not equal to -1 download values to uart */
    else if(index < access)
    {
        /*flag to print string for only once*/
            if ( index == 0 )
            {
                puts("Downloading...\n\r");
            }
        clcd_print("Downloading..",LINE1(1));
        
        /*find address and read characters from the address in eeproms*/
        addr = index * 16 + addr;
        for(int j=0;j<14;j++)
        {
            event[j]=eeprom_at24c04_read(addr+j); 
        }
        puts("Index : ");
        putchar(index+'0');
        puts("  ");
        puts(event);
        puts("\n\r");
        index++;
    }
    
    /* flag to print string for only once */
    if(index == access && once == 0 )
    {
        clear_screen_cursor_off();
        puts("Downloaded successfully\n\r");
        clcd_print("Downloaded",LINE1(2));
        clcd_print("successfully",LINE2(2));
        once = 1;
        __delay_ms(3000);
        clear_screen_cursor_off();
         return TASK_SUCCESS;
    }
}

/* function to change password */
unsigned char change_password (unsigned char reset_flag, unsigned char key)
{
    /* declare local variables */
    static char npassword[4],spassword[4],i=0,j=10,once=0,flag=1; 
    __delay_us(1000);
    
    /* if reset flag equal to reset password assign initial values to the variables*/
    if(reset_flag == RESET_PASSWORD)
    {
        i=0;j=10;
        once=0;
        flag=1;
    }
    
    /* flag to execute only once*/
    if(once == 0)
    {
        clcd_print("Enter password",LINE1(1));
                    clcd_write(LINE2(4), INST_MODE);
        clcd_write(DISP_ON_AND_CURSOR_ON, INST_MODE);
        once =1;
    }
    
    /*if switch 4 pressed read input as 1*/
    if (key == SW4 && i < 4) //store 1
    {
        spassword[i] = '1';
        clcd_putch('*', LINE2(5+i));
        i++;
        
    }
    /*if switch 5 pressed read input as 0 */
    else if (key == SW5 && i < 4) //store 0
    {
        spassword[i] = '0';
        clcd_putch('*', LINE2(5+i));
        i++;
    }
    
    /* if 4 characters read ,then initialize values to read reenter password*/
    else if(i == 4 && flag == 1)
    {
        clear_screen();
        clcd_write(DISP_ON_AND_CURSOR_OFF, INST_MODE);
        clcd_print("ReEnter password",LINE1(0)); 
        clcd_write(LINE2(4), INST_MODE);
        clcd_write(DISP_ON_AND_CURSOR_ON, INST_MODE);
        j=0;flag = 2;i++;
        spassword[i] = '\0';
    }
    
    /*if switch 4 pressed read input as 1*/    
    if (key == SW4 && i > 4 && j < 4) //store 1
    {
        npassword[j] = '1';
        clcd_putch('*', LINE2(5+j));
        j++;
        
    }

    /*if switch 5 pressed read input as 0 */
    else if (key == SW5 && i > 4 && j < 4) //store 0
    {
        npassword[j] = '0';
        clcd_putch('*', LINE2(5+j));
        j++;
    }
    
    /* if 4 values read then clear screen*/
    if(j == 4)
    {
        clear_screen();
       
        /* check if entered password and re entered password are same*/
        if (strncmp(spassword, npassword, 4) == 0)
        {
            
            /* if yes store password and print successfull*/
            clcd_print("Login Success", LINE1(2));
            clcd_write(DISP_ON_AND_CURSOR_OFF, INST_MODE);
            __delay_ms(1000);
            eeprom_at24c04_str_write(0x00,spassword);
             clear_screen_cursor_off();
            return TASK_SUCCESS;
            /* Display main menu */
         }
        
        /*if values not same display password miss match*/
        else if (strncmp(spassword, npassword, 4) != 0)
        {
            clcd_print("  mismatches  ", LINE1(1));
            clcd_print("Login failed", LINE2(2));
            __delay_ms(1000);
             clear_screen_cursor_off();
            return TASK_FAIL;
        }
    }
}

/* function to clear screen*/
void clear_screen(void) 
{
    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
    __delay_us(500);
}

/* function to clear screen and turn of cursor*/
void clear_screen_cursor_off(void)
{
    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
    __delay_us(500);
    clcd_write(DISP_ON_AND_CURSOR_OFF,INST_MODE);
    __delay_us(100);
}

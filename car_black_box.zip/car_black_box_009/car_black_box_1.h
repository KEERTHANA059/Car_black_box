/* 
 * File:   car_black_box_1.h
 * Author: R KEERTHANA
 */

#ifndef CAR_BLACK_BOX_1_H
#define	CAR_BLACK_BOX_1_H

/*functions prototypes*/
void display_dash_board(unsigned char event[],unsigned char speed);
void log_event(unsigned char event[],unsigned char speed);
void clear_screen(void);
void set_time(unsigned char reset_flag,unsigned char key);
void clear_screen_cursor_off(void);
void display_time(void);
unsigned char download_flag(unsigned char reset_flag);
unsigned char view_log(unsigned char reset_flag,unsigned char key);
unsigned char login(unsigned char reset_flag,unsigned char key);
unsigned char login_menu(unsigned char reset_flag,unsigned char key);
unsigned char clear_log(unsigned char reset_flag);
unsigned char change_password (unsigned char reset_flag, unsigned char key);
#endif	/* CAR_BLACK_BOX_1_H */


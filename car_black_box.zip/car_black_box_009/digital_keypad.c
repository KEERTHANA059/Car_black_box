/*
 * File:  digital keypad.c
 * Name : R KEERTHANA
 */

#include <xc.h>
#include "digital_keypad.h"

/*initialize digital keypad*/
void init_digital_keypad(void)
{
    /* Set Keypad Port as input */
    KEYPAD_PORT_DDR = KEYPAD_PORT_DDR | INPUT_LINES;
}

/*read input from digital keypad*/
unsigned char read_digital_keypad(unsigned char mode)
{
    /*declare local variables*/
    static char once = 0 ;
	static int longpressed = 1 ;
	static unsigned char pre_key ;
	unsigned char key =  KEYPAD_PORT & INPUT_LINES ;
    
    /*if any switch is pressed initialize variables*/
	if ( key != ALL_RELEASED && !once )
	{
		once = 1;
		longpressed = 0 ;
		pre_key = key;
	}
    
    /* if key released in short time return the same key values*/
	else if( key == ALL_RELEASED && once )
	{
		once = 0;
		if ( longpressed < 30 )
		return pre_key ;
	}
    
    /*increment the long pressed value*/
	else if (once && longpressed <= 30 )
		longpressed++;
    
    /*if key 4 is long pressed return L_SW4 value*/
	else if ( once && longpressed == 31  && key == SW4)
	{ 
		longpressed ++;
		return  L_SW4;
	} 
    
    /*if key 5 is long pressed return L_SW5 value*/
    else if ( once && longpressed == 31  && key == SW5)
	{ 
		longpressed++;
		return  L_SW5;
	}
    return ALL_RELEASED;
}

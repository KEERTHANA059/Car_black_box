/*
 * file     : isr.c
 * name     : R KEERTHANA
 * project  : car black box
 */
#include <xc.h>
#include "main.h"

/*extern variables from other files*/
extern int second,return_time,minute;
void __interrupt() isr(void)
{
	//declare local variables 
    static unsigned int count2 = 0;
 
//check if timer 2 flag is set or not
    if (TMR2IF == 1)
    {

// check the count value
        if (++count2 == 1250)
        {
            /*use minute , seconds variables to get delay*/
            if(minute >= 0)
            {
                if(second--  == 0)
                {
                    minute--;
                    second = 60;
                }
            }
            else if(return_time > 0 && second == 0)
                 return_time--;
            count2 = 0;
        }
        
        TMR2IF = 0;
    }
}
/*
 * File    :  main.c
 * Author  :  R KEERTHANA
 * project :  Car black box
 */


#include <xc.h>
#include "main.h"

#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)

int delay=0;

/*extern variables from other files*/
extern unsigned char clock_reg[3],new_time[3];
extern int timer_flag;

/*initial configuration*/
static void init_config(void) {
        //initialize clcd
    init_clcd();
    //initialize i2c
    init_i2c(100000);

    //initialize keypad
    init_digital_keypad();
    //initialize adc
    init_adc();
    //initialize rtc
    init_ds1307();
    //initialize uart
    init_uart(9600);
    //init_timer
    init_timer2();
    
    /*enable interrupts*/
    PEIE =1;
    GIE =1;
}

/* */
void main(void) {
    
    init_config();
    
    /*variable declarations*/
    unsigned char key,control_flag = 0x01,reset_flag,speed = 0x00;
    unsigned char event[3] ="ON",menu_pos,dummy;
    char *gear[]={"GN","GR","G1","G2","G3","G4"};
    int gr=0;
    
    /*read initial speed*/
    speed = read_adc();
    
    /*store initial infoo*/
    log_event(event,speed);
    //to store system password
    
    eeprom_at24c04_str_write(0x00, "1010");
    
    /*while loop to run black box*/
    while (1) {
        
        /*read adc as speed*/
        speed = read_adc();
        if(speed >99)
            speed=99;
        
        /*read digital keypad input*/
        key = read_digital_keypad(STATE);
        for(int b = 2000; b--; );
        
        /*if SW1 pressed load even as collision*/
        if(key == SW1)
        {
            strcpy(event,"C ");
            log_event(event,speed);
        }
        
        /*if switch2 pressed increase gear*/
        else if(key == SW2 && gr < 6)
        {
            strcpy(event,gear[gr]);
            gr++;
           log_event(event,speed);
        }
        
        /*if switch3 is pressed decrease gear position*/
        else if(key == SW3 && gr > 0)
        {
            gr--;
            strcpy(event,gear[gr]);
            log_event(event,speed);
        }
        
        /*if SW4 or SW5 pressed read password and login*/
        else if((control_flag == DASH_BOARD_FLAG) && (key == SW4 || key == SW5))
        {
            control_flag = LOGIN_FLAG;
            clear_screen();
            clcd_print("Enter password",LINE1(1));
            clcd_write(LINE2(4),INST_MODE);
            clcd_write(DISP_ON_AND_CURSOR_ON,INST_MODE);   
            __delay_ms(100);
            reset_flag = RESET_PASSWORD;
            TMR2ON = 1;
        }
        
        /* according to the switch position chose the task when SW4 long pressed*/
        else if( control_flag == LOGIN_MENU_FLAG && key == L_SW4 )
        {
                switch(menu_pos)
                {
				case 0:    //control jumps to view log flag                          
					clear_screen_cursor_off();
					control_flag = VIEW_LOG_FLAG;
					reset_flag = RESET_VIEW_LOG_POS ;
					break;
				case 1 :    //control jumps to clear log flag             
					clear_screen_cursor_off();
					control_flag = CLEAR_LOG_FLAG ;
					reset_flag = RESET_MEMORY;
					break;
				case 2 :    //control jumps to download log flag    
                    clear_screen_cursor_off();
					control_flag = DOWNLOAD_LOG_FLAG;
                    reset_flag = RESET_DOWNLOAD;
					break;
				case 3 :    //control jumps to set time flag    
					clear_screen_cursor_off();
					control_flag = SET_TIME_FLAG;
                    reset_flag = RESET_TIME;
					break;
				case 4:     //control jumps to change password flag    
					clear_screen_cursor_off();
					control_flag = CHANGE_PASSWORD_FLAG;
					reset_flag = RESET_PASSWORD;
					TMR2ON = 1;
					break;
                }
        }
        
        /* if switch 5 long pressed go back to dash board */
        else if ( key == L_SW5 && (control_flag == LOGIN_MENU_FLAG ||control_flag == VIEW_LOG_FLAG))
        {
        control_flag = DASH_BOARD_FLAG;
        clear_screen();
        }
        
        /*if switch 4 pressed go back to log menu*/
        else if ( key == L_SW4 && (control_flag == VIEW_LOG_FLAG ||control_flag == SET_TIME_FLAG || control_flag == DOWNLOAD_LOG_FLAG || control_flag == CLEAR_LOG_FLAG ))
        {
            /*if exiting from reset time load the time values into ds1307 RTC timer*/
            if(control_flag == SET_TIME_FLAG)
            {
                display_time();
                __delay_ms(3000); 
                clear_screen();
                dummy = ((new_time[0] / 10 ) << 4 ) | new_time[0] % 10 ;
                write_ds1307(HOUR_ADDR,(clock_reg[0] & 0xc0) | dummy) ;
                dummy = ((new_time[1] / 10 ) << 4 ) | new_time[1] % 10 ;
                write_ds1307(MIN_ADDR,(clock_reg[1] & 0x80) | dummy);
                dummy = ((new_time[2] / 10 ) << 4 ) | new_time[2] % 10 ;
                write_ds1307(SEC_ADDR, (clock_reg[2] & 0x80) | dummy);
                
                clcd_print("    Set time    ",LINE1(0));
                clcd_print("   successful   ",LINE2(0));
                timer_flag = 1;
                __delay_ms(2000);   
            }
            control_flag = LOGIN_MENU_FLAG;
            clear_screen();
        }
        /*buy some delay*/
        for(int b = 3000; b--; );
        
        /*according to the control flag call functions*/
        switch(control_flag)
        {
            case DASH_BOARD_FLAG:                //call dash board function display
                display_dash_board(event,speed);
                break;
            case LOGIN_FLAG:                     
            {
   /*after login check if password entered is correct or return to dash board if password not pressed*/
                switch(login(reset_flag,key))    
                {
                    case RETURN_BACK:
                        clear_screen_cursor_off();
                        control_flag = DASH_BOARD_FLAG;
                        TMR2ON=0;
                        break;
                    case LOGIN_SUCCESS:
                        clear_screen_cursor_off();
                        control_flag=LOGIN_MENU_FLAG;
                        reset_flag = RESET_PASSWORD;
                        continue;
                        break;
                }
                break;
            }
            
            /*display menu in clcd*/
            case LOGIN_MENU_FLAG:
            {
                menu_pos = login_menu(reset_flag,key);
                break;
            }
            
            /*display login history*/
            case VIEW_LOG_FLAG:
            {
                reset_flag = view_log(reset_flag,key);
                if(reset_flag == TASK_FAIL )
                {
                    control_flag = DASH_BOARD_FLAG;
                }
                break;
            }
            
            /*clear the login history*/
            case CLEAR_LOG_FLAG:
            {
                clear_log(reset_flag);
                control_flag = LOGIN_MENU_FLAG;
                reset_flag = RESET_PASSWORD;
                break;
            }
            
            /*change timer using clcd and digital keypad*/
            case SET_TIME_FLAG:
            {
                set_time(reset_flag,key);
                break;
            }
            
            /*download all the logins and simply using uart protocol*/
            case DOWNLOAD_LOG_FLAG:
            {
                reset_flag = download_flag(reset_flag);   
                if(reset_flag == TASK_SUCCESS )
                {
                    control_flag = LOGIN_MENU_FLAG;
                }
                if(reset_flag == TASK_FAIL )
                {
                    control_flag = DASH_BOARD_FLAG;
                }
                break;
            }
            
            /* change user password using digital keypad*/
            case CHANGE_PASSWORD_FLAG:
            {
                reset_flag = change_password(reset_flag,key);
                if(reset_flag == TASK_FAIL )
                    control_flag = LOGIN_MENU_FLAG;
                if(reset_flag == TASK_SUCCESS)
                    control_flag = DASH_BOARD_FLAG;
                break;
            }
        }
        reset_flag = RESET_NOTHING;
    }
    return;
}


/* 
 * File:   timers.h
 * Author: R KEERTHANA
 */

#ifndef TIMERS_H
#define	TIMERS_H
    
void init_timer2(void);

#endif	/* TIMERS_H */

